# Career Darpan — setup guide (বাংলা)

এই ZIP-এ Android Studio source project, Firebase Authentication/Firestore/Storage integration-এর starter code এবং security rules আছে। **এটি এখনও compile করা APK নয় এবং আপনার Firebase project-এ deploy করা হয়নি।** Firebase account/configuration ছাড়া বাস্তব Admin/Teacher/Student login বা একাধিক ফোনে cloud upload চালু করা সম্ভব নয়।

## ১) Login-এর নিয়ম

### Super Admin (প্রতিষ্ঠানের মালিক)
- Login ID: আপনার নিজের email address
- Password: Firebase Authentication-এ আপনি যে password তৈরি করবেন
- Role: `superadmin`
- সব শিক্ষক ও ছাত্রের access নিয়ন্ত্রণ করবেন; শিক্ষক সক্রিয়/নিষ্ক্রিয় করতে পারবেন (Firestore user profile পরিবর্তন করে)।

### Teacher Admin
- Login ID: শিক্ষককে দেওয়া email address
- Password: Firebase Authentication-এ সেট করা password
- Role: `teacher`
- অ্যাপ থেকে PDF/ছবি upload এবং notice publish করতে পারবেন।
- অন্য শিক্ষক নিয়োগ, role বদল বা student account administration করতে পারবেন না।

### Student
- Login ID: আপনার দেওয়া Student ID, যেমন `CD2027001`
- Password: Firebase Authentication-এ সেট করা password
- অ্যাপ Student ID-কে internally `CD2027001@login.careerdarpan.app` email alias-এ রূপান্তর করে।
- Role: `student`
- প্রকাশিত study materials, notices, quiz এবং নিজের result দেখতে পারবে।

**কোনও password এই project-এ hard-code করা নেই। কাউকে নিজের password দেবেন না।**

## ২) Firebase project তৈরি

1. https://console.firebase.google.com/ খুলে Google account দিয়ে sign in করুন।
2. Add project → Project name `career-darpan` (নামটি উপলব্ধ না হলে অন্য unique ID দিন)।
3. Project তৈরি হলে Project Overview → Web app (</>) নির্বাচন করে app register করুন।
4. Firebase যে `firebaseConfig` দেখাবে, সেটি `app/src/main/assets/index.html` ফাইলে `const firebaseConfig` অংশে বসান। `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId` সবই Firebase থেকে হুবহু নেবেন।
5. Authentication → Sign-in method → Email/Password enable করুন।
6. Firestore Database তৈরি করুন (Production mode)।
7. Firestore → Rules-এ `firebase/firestore.rules`-এর content paste করে Publish করুন।

## ৩) Super Admin account bootstrap

1. Firebase Console → Authentication → Users → Add user।
2. নিজের email এবং নিজের তৈরি করা শক্তিশালী password দিন।
3. তৈরি হওয়া account-এর UID কপি করুন।
4. Firestore Database → Data → Start collection: `users`।
5. Document ID হিসেবে ওই UID বসান।
6. এই fields যোগ করুন:
   - `role` (string): `superadmin`
   - `displayName` (string): `Career Darpan Admin`
   - `active` (boolean): `true`
7. এখন অ্যাপে নিজের email/password দিয়ে login করলে Super Admin dashboard পাবেন।

**সতর্কতা:** প্রথম Super Admin profile নিজে Console-এ bootstrap করতে হয়। Firestore rules-এ role assignment কেবল Super Admin-কে দেওয়া হয়েছে। Firebase Console project owner access নিজের কাছে সুরক্ষিত রাখুন।

## ৪) Teacher account তৈরি ও অনুমতি দেওয়া

প্রতিটি শিক্ষককে যোগ করার জন্য (প্রথম সংস্করণে Firebase Console ব্যবহার করতে হবে):
1. Authentication → Users → Add user; শিক্ষকের email ও temporary password দিন।
2. শিক্ষকের UID কপি করুন।
3. Firestore `users` collection-এ UID-কে Document ID করে document তৈরি করুন।
4. fields:
   - `role` (string): `teacher`
   - `displayName` (string): শিক্ষকের নাম
   - `active` (boolean): `true`
5. শিক্ষকের email ও অস্থায়ী password নিরাপদভাবে তাঁকে দিন; তাঁকে login-এর পর password পরিবর্তনের নির্দেশ দিন (Firebase Console থেকে password reset করানো যায়)।

শিক্ষকের access বন্ধ করতে `active=false` করুন। শিক্ষক নিজে role পরিবর্তন করতে পারবেন না।

## ৫) Student account তৈরি

প্রতি ছাত্রের জন্য:
1. Authentication → Users → Add user।
2. Email ঘরে Student ID alias দিন, যেমন `CD2027001@login.careerdarpan.app`।
3. একটি temporary password দিন।
4. UID কপি করুন।
5. Firestore `users` collection-এ ওই UID document তৈরি করুন:
   - `role`: `student`
   - `displayName`: ছাত্রের নাম
   - `studentId`: `CD2027001`
   - `active`: `true`
6. ছাত্র অ্যাপে Email নয়, `CD2027001` এবং password দিয়ে login করবে।

Student ID যেন unique হয়। Password ভুলে গেলে Admin Firebase Console → Authentication → ওই user → Reset password ব্যবহার করবেন। এই prototype-এ student self-service reset UI নেই।

## ৬) Cloud Storage — গুরুত্বপূর্ণ খরচের বিষয়

এই app-এর in-app PDF/image upload Firebase Cloud Storage ব্যবহার করে। Firebase-এর বর্তমান নিয়মে নতুন Cloud Storage bucket তৈরি ও ব্যবহার করতে **Blaze pay-as-you-go billing plan** লাগবে এবং billing account/payment method link করতে হয়। No-cost usage allowance থাকতে পারে, কিন্তু billing account ছাড়া এই in-app upload চালু হবে না; quota ছাড়ালে টাকা কাটতে পারে। তাই billing enable করার আগে Google Cloud budget alert সেট করুন এবং আপনার অনুমতি ছাড়া upgrade করবেন না।

- Firebase Console → Storage → Get started (Blaze plan চাইতে পারে)।
- bucket তৈরি হলে Storage Rules-এ `firebase/storage.rules` paste করে Publish করুন।
- `firebaseConfig.storageBucket`-এ Firebase Console-এর exact bucket value বসান।
- এই starter upload-এ PDF/image সর্বোচ্চ 20 MB।
- Video ফাইল upload না করে YouTube link দিতে পারবেন; app-এর current form-এ Video URL field আছে।

যদি এখনই payment method যোগ করতে না চান, Storage চালু করবেন না। সে ক্ষেত্রে teachers Google Drive/YouTube-এ file host করে app-এর Firestore material record-এ URL manually রাখতে হবে—এই starter UI-তে external-link publish flow এখনো যোগ করা হয়নি।

## ৭) Android APK তৈরি

1. Computer-এ Android Studio install করুন: https://developer.android.com/studio
2. Android Studio → Open → এই ZIP extract করা `CareerDarpan_Full_Source` folder নির্বাচন করুন।
3. Gradle Sync শেষ হতে দিন।
4. Firebase config বসিয়ে app rebuild করুন।
5. Build → Build Bundle(s) / APK(s) → Build APK(s)।
6. APK পাবেন `app/build/outputs/apk/debug/app-debug.apk`-এ।
7. নিজের Android phone-এ APK পাঠিয়ে install করুন। Android-এ প্রয়োজন হলে “Install unknown apps” অনুমতি দিন।
8. ছাত্রছাত্রীদের দেওয়ার আগে একাধিক test account দিয়ে login, upload, download, permissions পরীক্ষা করুন।
9. Public distribution-এর জন্য Build → Generate Signed Bundle / APK থেকে signed release APK বানান; keystore/password নিরাপদে রাখুন।

এই execution environment-এ Android SDK/Gradle build-tools নেই, তাই এখানে APK compile/test করা হয়নি।

## ৮) Ads / AdMob

এই source-এ AdMob SDK বা আপনার ad unit IDs এখনো যুক্ত নেই। AdMob account, Android app registration, App ID ও Banner/Interstitial ad unit IDs লাগবে। Google-এর policy মেনে ads যোগ ও review সম্পন্ন না হওয়া পর্যন্ত আয় হবে না। নিজের app-এ live ads-এ click করবেন না; development-এ test ads ব্যবহার করতে হবে।

## ৯) বর্তমান prototype-এর সীমা

- Role-based login, materials metadata, Firebase Storage upload/download, notices-এর starter implementation আছে।
- User account provisioning প্রথমে Firebase Console-এ করতে হবে; অ্যাপের ভিতরে শিক্ষক/ছাত্র account creation UI নেই।
- Result publishing/admin grading, full exam engine, push notification, AdMob integration, analytics, profile editing এবং forgot-password screen এখনো পূর্ণাঙ্গ নয়।
- Course list সাধারণ কাঠামো; নির্দিষ্ট WBCHSE/বিশ্ববিদ্যালয়ের syllabus যাচাই করে material যোগ করবেন।
- Firestore index প্রয়োজন হলে Firebase error link থেকে index তৈরি করুন।

## Self-registration (updated build)

- The app now offers Student and Teacher self-registration. Students receive an automatically generated ID in the form `CD` + 7 timestamp digits + 2 random digits; the app maps this ID to an internal Firebase Auth email alias. Teachers register with their own email address.
- Both account types are written to `users/{uid}` with `active: false` and `status: "pending"`. The user cannot enter the app until the Super Admin approves the profile.
- Publish the updated `firebase/firestore.rules` in Firestore Rules before testing registration. These rules allow a signed-in user to create only their own pending student/teacher profile; only the active Super Admin can list users and approve/reject them.
- After Super Admin approval, the profile's `active` field becomes true. Teacher uploads remain restricted by the Storage rules to active teachers and Super Admin.
- A rejected account remains disabled; to reconsider it, the Super Admin can approve its pending profile. For production, add email verification, stronger phone validation, abuse protection/App Check, and a trusted server-side ID allocator if strict sequential IDs are required.
- The current generated ID is unique-looking but not sequential and has a very small collision possibility; verify no duplicate before production or replace with a server-generated allocator.
