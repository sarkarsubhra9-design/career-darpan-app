# Career Darpan Android source project

Bilingual (Bengali/English) Android WebView starter with Firebase Authentication, Firestore role profiles, Firestore study-material metadata, Firebase Storage PDF/image upload, and teacher/admin/student role-based screens.

## Read first
Open `FIREBASE_SETUP_BN.md` before using. Firebase project config and role bootstrap are mandatory. This is **source code, not a compiled APK**. This environment did not have Android SDK/Gradle build tools to compile or test an APK.

## Roles
- `superadmin`: owner; full access
- `teacher`: upload/publish materials and notices
- `student`: view published materials/notices and sample quiz

## Important billing note
Current Firebase Cloud Storage requires Blaze billing for new buckets / continued access. A payment method is required for the billing account. No-cost allowances may apply, but usage above them can incur charges. Firestore and Authentication have no-cost quotas. Do not enable billing until you approve it and set budget alerts.

## Security
Firestore rules: `firebase/firestore.rules`
Storage rules: `firebase/storage.rules`
Do not weaken these rules or let clients write their own roles. Create role documents only through trusted Firebase Console/Admin SDK.

## Build
Open this folder in Android Studio, configure Firebase in `app/src/main/assets/index.html`, sync Gradle, then Build > Build Bundle(s) / APK(s) > Build APK(s). See the Bengali setup guide for details.

### Self-registration update
Students and teachers can register in-app. New accounts are pending (`active:false`) until the Super Admin approves them from the Manage Users tab. Students receive an automatically generated non-sequential Student ID; teachers use their email. Publish the updated Firestore rules before testing. This source is a prototype and has not been built or runtime-tested as an APK.
