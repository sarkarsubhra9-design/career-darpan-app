# Career Darpan — মোবাইল থেকে APK Build

এই ZIP-এ Android Studio/Gradle source project আছে। এটি নিজে APK নয় এবং এখানে compile বা device-test করা হয়নি।

## Firebase সংযোগ
- `app/src/main/assets/index.html`-এ Career Darpan Firebase Web App configuration বসানো আছে।
- Firebase project ID: `career-darpan`.
- Authentication Email/Password ও Firestore ব্যবহার করা হয়েছে।

## বর্তমান prototype
- Student ও Teacher registration form আছে।
- Registration `users/{uid}`-এ `active:false`, `status:'pending'` হিসেবে লেখা হয়।
- Super Admin users panel থেকে pending registration approve/reject করতে পারে।
- Approved teachers materials upload এবং notices publish করতে পারে।
- Student login ID হিসেবে auto-generated Student ID ব্যবহৃত হয়।

## সীমাবদ্ধতা ও সতর্কতা
- এটি প্রাথমিক prototype; সম্পূর্ণ production-ready app নয়।
- Android APK build, Firebase integration runtime, upload, approval flow বাস্তবে পরীক্ষা করা হয়নি।
- Firestore Rules ও app code-এর সব ক্ষেত্র production deployment-এর আগে পরীক্ষা করা প্রয়োজন।
- Firebase Storage upload ব্যবহারের জন্য Firebase Console-এ Storage bucket ও billing eligibility/plan সেটআপ লাগতে পারে; Blaze billing নিজে থেকে চালু করবেন না। Video URL ব্যবহার করা যায়।
- Release APK বিতরণের আগে নিজস্ব signing keystore তৈরি করে নিরাপদে ব্যাকআপ রাখুন।
- Firebase Web API key web config-এর অংশ; service-account key বা private credential কখনও GitHub-এ দেবেন না।
